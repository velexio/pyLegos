A enterprise framework for developing true enterprise python applications
===============================================================================
This project is designed to assist in building modern python applications and projects that meet the needs of an
enterprise level application.  There are many frameworks that exist for creating python web applications and/or web
apis using python.  However, there are needs of enterprise level applications that are not met by these frameworks.
-----
PyLegos borrows many of the concepts used by other application frameworks.  The framework is somewhat opinionated.  It
currently requires a particular file structure.  In future releases we hope to eliminate this requirement so that the
structure can be adjusted to meet the style of the development team.




