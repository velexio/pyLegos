import argparse

class CliArgs(object):

    def parse(self):
        return None


def main():

    cliArgs = CliArgs().parse()
    print('hello')